Android-Send-SMS-using-SmsManager-API-Code-Sample
=================================================

This example is using the smsManager API to send out the SMS message.

You can find complete tutorial on how to use the code repo here : <a href="http://www.theappguruz.com/blog/android-send-sms-using-smsmanager-api">ANDROID – SEND SMS USING SMSMANAGER API</a>

This Tutorial has been presented by The App Guruz - One of the best <a href="http://www.theappguruz.com/android-app-development/">Android App Development Company in India</a>
